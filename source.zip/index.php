<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d67712fb             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\x72\137\x75\164\151\x6c\x69\164\171\x5f\x64\157\143\165\155\145\x6e\x74\137\x67\x65\x74\x5f\x70\144\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
