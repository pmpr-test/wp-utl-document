<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d469f52c9a             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\162\137\165\x74\x69\x6c\151\164\x79\137\144\x6f\x63\x75\x6d\145\156\x74\137\x67\145\164\x5f\x70\x64\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
