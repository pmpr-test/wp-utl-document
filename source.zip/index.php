<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd85f4db             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\x70\162\137\165\x74\x69\154\151\x74\x79\x5f\144\157\x63\165\x6d\145\156\164\137\x67\x65\x74\137\160\x64\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
