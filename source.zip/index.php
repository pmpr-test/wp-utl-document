<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c80d3b6f             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\162\x5f\165\164\x69\154\151\x74\x79\x5f\x64\x6f\143\165\x6d\x65\156\x74\137\x67\145\x74\x5f\160\144\146")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
