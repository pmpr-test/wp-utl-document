<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3d3abb945             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\x72\137\165\164\151\154\151\x74\171\137\144\x6f\x63\165\x6d\x65\156\x74\x5f\147\x65\x74\x5f\x70\x64\146")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
