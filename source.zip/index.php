<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b0a9396             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\160\x72\137\x75\164\x69\154\151\164\x79\x5f\144\157\143\165\x6d\x65\156\164\137\x67\145\164\x5f\x70\x64\146")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
