<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff67353a             |
    |_______________________________________|
*/
 use Pmpr\Utility\Document\Document; use Pmpr\Utility\Document\PDF; Document::symcgieuakksimmu(); if (!function_exists("\x70\x72\x5f\x75\164\x69\x6c\x69\164\x79\x5f\144\x6f\143\165\x6d\145\156\x74\x5f\x67\x65\164\137\160\144\x66")) { function pr_utility_document_get_pdf() : PDF { return PDF::symcgieuakksimmu(); } }
