<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cfff67353a             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\LightContainer; class Container extends LightContainer { }
