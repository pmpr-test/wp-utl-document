<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678d3c80d3b6f             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\LightContainer; abstract class Container extends LightContainer { }
