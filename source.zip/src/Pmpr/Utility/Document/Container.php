<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd85f4db             |
    |_______________________________________|
*/
 namespace Pmpr\Utility\Document; use Pmpr\Common\Foundation\Container\LightContainer; class Container extends LightContainer { }
